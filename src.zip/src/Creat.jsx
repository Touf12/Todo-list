import { useState } from 'react';
import axios from 'axios';

// eslint-disable-next-line react/prop-types
function Create({ setTodos, todos }) {
  const [task, setTask] = useState('');

  const handleAdd = () => {
    axios.post('http://localhost:3001/add', { task })
      .then(result => {
        console.log(result);
      
        setTodos([...todos, result.data.task]);
        setTask(''); 
      })
      .catch(err => console.error('Error adding task:', err));
  };

  return (
    <div className="create-form">
      <input
        type="text"
        placeholder="Enter task"
        value={task}
        onChange={(e) => setTask(e.target.value)}
      />
      <button type="button" onClick={handleAdd}>Add your task</button>
    </div>
  );
}

export default Create;
