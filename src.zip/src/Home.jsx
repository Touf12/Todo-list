// eslint-disable-next-line no-unused-vars
import React, { useState } from 'react';
import Create from './Creat';
import './App.css';

function Home() {
  const [todos, setTodos] = useState([]);

  return (
    <div className="home">
      <h2>TODO LIST</h2>
      <Create setTodos={setTodos} todos={todos} />
      
      {todos.length === 0 ? (
        <div className="no-record">
          <h2>No record</h2>
        </div>
      ) : (
        todos.map((todo, index) => (
          <div key={index} className="todo-item">
            <p>{todo}</p>
            <button onClick={() => setTodos(todos.filter((t, i) => i !== index))}>Delete</button>
          </div>
        ))
      )}
    </div>
  );
}

export default Home;


// import pyttsx3
// import speech_recognition as sr
// import datetime
// import pyaudio
// import wikipedia
// import webbrowser
// import smtplib

// # Initialize the text-to-speech engine
// engine = pyttsx3.init('sapi5')
// voices = engine.getProperty('voices')

// # Set the voice property to the first voice in the list (adjust index as needed)
// engine.setProperty('voice', voices[0].id)

// # List available audio devices
// p = pyaudio.PyAudio()
// for i in range(p.get_device_count()):
//     print(f"Device {i}: {p.get_device_info_by_index(i)}")

// def speak(audio):
//     """Converts text to speech."""
//     engine.say(audio)
//     engine.runAndWait()

// def wishMe():
//     """Wishes the user based on the time of day and introduces itself."""
//     hour = int(datetime.datetime.now().hour)
//     if hour >= 0 and hour < 12:
//         speak("Good Morning!")
//     elif hour >= 12 and hour < 18:
//         speak("Good Afternoon!")
//     else:
//         speak("Good Evening!")

//     speak("I am Jarvis, Sir.")

// def takeCommand():
//     """Listens for a command and returns the recognized text."""
//     r = sr.Recognizer()
//     mic_index = 1  # Change this to your device index
//     with sr.Microphone(device_index=mic_index) as source:
//         print("Listening...")
//         r.pause_threshold = 1
//         audio = r.listen(source)

//     try:
//         print("Recognizing...")
//         query = r.recognize_google(audio, language='en-in')
//         print(f"User said: {query}\n")
//     except sr.UnknownValueError:
//         print("Google Speech Recognition could not understand audio")
//         return "None"
//     except sr.RequestError as e:
//         print(f"Could not request results from Google Speech Recognition service; {e}")
//         return "None"
//     except Exception as e:
//         print(e)
//         print("Say that again please...")
//         return "None"
//     return query

// def sendEmail(to, content):
//     """Sends an email."""
//     server = smtplib.SMTP('smtp.gmail.com', 587)
//     server.ehlo()
//     server.starttls()
//     server.login('toufikchawware@gmail.com', 'TOufik@786')
//     server.sendmail('toufikchawware@gmail.com', to, content)
//     server.close()

// if __name__ == "__main__":
//     wishMe()
//     while True:
//         query = takeCommand().lower()
//         # Logic for executing tasks based on query
//         if 'wikipedia' in query:
//             speak("Searching Wikipedia...")
//             query = query.replace("wikipedia", "")
//             results = wikipedia.summary(query, sentences=2)
//             speak("According to Wikipedia")
//             print(results)
//             speak(results)

//         elif 'open youtube' in query:
//             speak("Opening YouTube")
//             webbrowser.open('youtube.com')

//         elif 'open google' in query:
//             speak("Opening Google")
//             webbrowser.open('google.com')

//         elif 'the time' in query:
//             strTime = datetime.datetime.now().strftime("%H:%M:%S")
//             speak(f"Sir, the time is {strTime}")

//         elif 'email to topic' in query:
//             try:
//                 speak("What should I say?")
//                 content = takeCommand()
//                 to = "toufikchawware@gmail.com"
//                 sendEmail(to, content)
//                 speak("Email has been sent!")
//                 print("Email has been sent!")
//             except Exception as e:
//                 print(e)
//                 speak("Sorry Sir, I am not able to send this email at the moment.")

