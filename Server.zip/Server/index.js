const express = require('express')
const mongoose = require('mongoose')
const cors = require('cors')
const TodoModel = require('./Models/Todo')

const app = express()
app.use(cors())
app.use(express.json())

mongoose.connect('mongodb://127.0.0.1:27017/test')
  .then(() => {
    console.log('Connected to MongoDB')
  })
  .catch(err => {
    console.error('Failed to connect to MongoDB', err)
  })


app.post('/add', (req, res) => {
  const task = req.body.task;
  
  TodoModel.create({ task })
    .then(result => res.status(201).json(result))
    .catch(err => res.status(500).json({ error: err.message }))
})

app.listen(3001, () => {
  console.log("Server is Running on port 3001")
})
